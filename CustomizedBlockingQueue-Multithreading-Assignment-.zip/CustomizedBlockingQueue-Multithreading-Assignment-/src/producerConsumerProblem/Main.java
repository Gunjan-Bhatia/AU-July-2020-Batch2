package producerConsumerProblem;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws InterruptedException {


    	Scanner s = new Scanner(System.in);
        Queue blockingQueue = new LinkedList < Integer >();
         
        System.out.println("Enter number of consumers needed : ");
        int numConsumer = s.nextInt();
        Thread consumer = new Thread(new Consumer(blockingQueue, numConsumer), "consumer");
        
        System.out.println("Enter number of producers needed : ");
        int numProducer = s.nextInt();
        Thread producer = new Thread(new Producer(blockingQueue, numProducer), "producer");

        producer.start();
        consumer.start();

        s.close();
    }

}




