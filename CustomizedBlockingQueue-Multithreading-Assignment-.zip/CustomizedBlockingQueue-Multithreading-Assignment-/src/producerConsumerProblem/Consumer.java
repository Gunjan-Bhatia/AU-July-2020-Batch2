package producerConsumerProblem;

import java.util.Queue;


class Consumer implements Runnable
{
    private final Queue<Integer> blockingQueue;
    private int capacity ;

    public Consumer(Queue<Integer> blockingQueue, int capacity)
    {
        this.blockingQueue = blockingQueue;
        this.capacity = capacity;
    }

    @Override
    public void run(){
        while(true)
        {
            synchronized (blockingQueue) {
                while(blockingQueue.isEmpty())
                {
                    try {
                        System.out.println("Queue is Empty you can't consume");
                        blockingQueue.wait(100000,10000);
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }

                int number =  blockingQueue.poll();
                System.out.println("You are able to consume");
                blockingQueue.notify();

            }
        }
    }

}