package producerConsumerProblem;

import java.util.Queue;


class Producer implements Runnable
{
    private final Queue<Integer> blockingQueue;
    private int capacity;

    public Producer(Queue<Integer> blockingQueue, int capacity)
    {
        this.blockingQueue = blockingQueue;
        this.capacity = capacity;
    }

    @Override
    public void run(){

        while(true)
        {
            synchronized (blockingQueue) {
                while(blockingQueue.size() == capacity)
                {
                    try
                    {
                        System.out.println("Can't produce more queue is full");
                        blockingQueue.wait(100000,10000);
                        
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }

                }
                
                
                blockingQueue.add(0);
                blockingQueue.notifyAll();
                

            }

        }
    }
}